# Design Assets

This directory contains design mockups and screenshots used during the development process.

## Files

- PNG images showing various UI states and design iterations
- Mobile and desktop view mockups
- Header and search bar design references

These assets were used to guide the UI/UX implementation of the application.
