Sample1 (C# <---> AHK)
1. Host.exe (C#)
2. Client.ahk (AHK)


Sample2 (AHK <---> AHK)
1. Scritp1 (AHK)
2. Script2 (AHK)