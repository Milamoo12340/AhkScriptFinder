Check out these alternatives  
- https://github.com/G33kDude/Console
- https://github.com/NickMcCoy/AHK-Console-Class
